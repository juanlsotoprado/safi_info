<?php
// $Header: /cvsroot/html2ps/tag.input.inc.php,v 1.21 2005/11/12 06:29:24 Konstantin Exp $

// define('DEFAULT_BUTTON_HORIZONTAL_PADDING','5 px');

?>