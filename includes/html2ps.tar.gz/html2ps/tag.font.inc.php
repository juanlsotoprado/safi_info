<?php
// $Header: /cvsroot/html2ps/tag.font.inc.php,v 1.3 2005/06/28 15:56:09 Konstantin Exp $
?>