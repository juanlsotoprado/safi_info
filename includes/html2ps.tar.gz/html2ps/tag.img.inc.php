<?php
// $Header: /cvsroot/html2ps/tag.img.inc.php,v 1.11 2005/11/12 06:29:24 Konstantin Exp $

?>