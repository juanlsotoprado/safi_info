<?php
// $Header: /cvsroot/html2ps/css.frame.inc.php,v 1.2 2005/09/25 16:21:44 Konstantin Exp $


?>